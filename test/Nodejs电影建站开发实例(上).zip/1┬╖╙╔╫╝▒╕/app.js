var express = require('express');
var mongoose =require('./config/mongoose.js');
var db = mongoose();
var app = express();
var bodyParser = require('body-parser');
var path = require('path');
var port = process.env.PORT || 3030;

//指定模板引擎
app.set("view engine", 'jade');

//指定模板位置
app.set('views', './views/pages');

//将表单数据格式化
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({
    extended: true
})); 

//设置静态资源
app.use(express.static(path.join(__dirname, './public')));


var admin=require('./routes/admin');
var index=require('./routes/index');
var movie=require('./routes/movie');

//路由设置
app.use('/admin',admin);
app.use('/',index);
app.use('/movie',movie);




//npm start启动
//module.exports = app;

app.listen(port);
console.log("start on port:"+port);