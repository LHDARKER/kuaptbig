var express = require("express");
var app=express();
var path = require('path');



//设置模板引擎
app.set("view engine",'jade');
app.set('views','./views/pages');

//设置静态资源
app.use(express.static(path.join(__dirname, './public')));


//访问网站跟目录：localhost:3000/
app.get("/",function(req,res){
    res.render('index.jade',{
        title:'网站首页',
        movies:{}
    });
});


//localhost:3000/movie/1
app.get("/movie/:id",function(req,res){
    res.render('detail.jade',{
        title:'电影详情',
        movie:{}
    })
});


//localhost:3000/admin/add
app.get("/admin/add",function(req,res){
    res.render('control.jade',{
        title:'后台电影添加页',
        movie:{}
    });
});


//localhost:3000/admin/list
app.get("/admin/list",function(req,res){
    res.render('list.jade',{
        title:'后台电影列表',
      movies:{}
    });
});




app.listen(3000,function(){
    console.log("请访问http://localhost:3000");
});